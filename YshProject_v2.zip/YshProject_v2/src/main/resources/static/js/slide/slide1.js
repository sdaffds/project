/**
 * 
 */
 
 $(function(){
	slideOne();
});
 
 // 1, 2, 3, 4, 5(1), 6 600%
 var index = 1;
 
 function slideOne(){
	index++;
	$("#slider-wrap #slider").animate({
		"left" : -1000*(index-1)+"px"
	},1000);
	
	if(index == 5){
		$("#slider-wrap #slider").animate({
			"left" : 0+"px"
		},0)
	index = 1;
	}
	setTimeout("slideOne()",3000);	// 무한 슬라이드 할 때만
}