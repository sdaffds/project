package ysh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YshProjectV2Application {

	public static void main(String[] args) {
		SpringApplication.run(YshProjectV2Application.class, args);
	}

}
