package ysh.domain.dto.notice;

import lombok.Getter;
import ysh.domain.entity.BaseEntity;
import ysh.domain.entity.NoticeEntity;


@Getter
public class NoticeListDto extends BaseEntity{// Repository 접근가능

	private long no;
	private String subject;
	
	private int readCount;
	
	private String email;
	
	private String writer;

	
	/*
	 * NoticeEntity 가 인자로 들어가는 생성자가 필요
	 */
	public NoticeListDto(NoticeEntity entity) {
		this.no = entity.getNo();
		this.subject = entity.getSubject();
		this.readCount = entity.getReadCount();
		this.email = entity.getMember().getEmail();
		this.writer = entity.getMember().getName();
		
		createdDate=entity.getCreatedDate();
		updatedDate=entity.getUpdatedDate();
	}
	
	
	
	
}
