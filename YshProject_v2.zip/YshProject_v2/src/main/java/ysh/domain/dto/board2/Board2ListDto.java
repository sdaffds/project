package ysh.domain.dto.board2;

import lombok.Getter;
import lombok.Setter;
import ysh.domain.entity.BaseEntity;
import ysh.domain.entity.Board2E;

@Getter
@Setter
public class Board2ListDto extends BaseEntity {

    private long no;
    private String subject;

    private int readCount;

    private String email;

    private String writer;

    public Board2ListDto(Board2E entity) {
        this.no = entity.getNo();
        this.subject = entity.getSubject();
        this.readCount = entity.getReadCount();
        this.email = entity.getMember().getEmail();
        this.writer = entity.getMember().getName();

        createdDate = entity.getCreatedDate();
        updatedDate = entity.getUpdatedDate();
    }
}
