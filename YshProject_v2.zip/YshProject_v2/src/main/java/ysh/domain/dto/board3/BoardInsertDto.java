package ysh.domain.dto.board3;

import lombok.Data;

@Data
public class BoardInsertDto {

	private String subject;
	private String editordata;
}
