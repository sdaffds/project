package ysh.domain.dto.util;

import lombok.Getter;

@Getter
public class PageDto {
	
	
	private int from; //시작하는 페이지번호
	private int to;   //끝나는 페이지번호
	private int pageTotal;
	
	
	/**
	 * @param pageGroup : 페이지개수  
	 * @param page      : 페이지번호   1 부터 
	 * @param pageTotal : 총페이지수   getTotalPages()-- Page<T> 
	 */
	public PageDto(int pageGroup, int page, int pageTotal) {
		this.pageTotal=pageTotal;
		
		int pageGroupNo=page / pageGroup; // 1/5(0),2/5(0),3/5(0),4/5(0),5/5(1) : 1그룹
		if(page % pageGroup > 0) pageGroupNo++;
		
		to = pageGroupNo * pageGroup; //마지막번호
		from = to-pageGroup+1;        //시작번호
		//마지막페이지 번호 체크
		if(to>pageTotal) to=pageTotal;
	}

}
