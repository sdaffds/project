package ysh.domain.dto.member;

import lombok.Data;

@Data
public class MemberSaveDto {

	private String email;
	private String password;
	private String name;
	
	
}
