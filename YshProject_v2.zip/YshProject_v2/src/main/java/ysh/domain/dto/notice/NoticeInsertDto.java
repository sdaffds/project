package ysh.domain.dto.notice;

import lombok.Data;

@Data
public class NoticeInsertDto {
	
	private String subject;
	private String content;
}

