package ysh.domain.dto.board3;

import lombok.Getter;
import ysh.domain.entity.BaseEntity;
import ysh.domain.entity.BoardEntity;


@Getter
public class BoardDetailDto extends BaseEntity{// Repository 접근가능

	private long no;
	private String subject;
	private String content;
	
	private int readCount;
	
	private String email;

	public BoardDetailDto(BoardEntity entity) {
		this.no = entity.getNo();
		this.subject = entity.getSubject();
		this.content = entity.getContent();
		this.readCount = entity.getReadCount();
		this.email = entity.getMember().getEmail();
		
		createdDate=entity.getCreatedDate();
		updatedDate=entity.getUpdatedDate();
	}
	
	
	
	
}
