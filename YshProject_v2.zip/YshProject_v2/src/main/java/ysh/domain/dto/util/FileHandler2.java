package ysh.domain.dto.util;

import java.io.File;
import java.io.IOException;

import com.google.gson.JsonObject;

import org.springframework.core.io.ClassPathResource;
import org.springframework.web.multipart.MultipartFile;

public class FileHandler2 {

    // TODO 로컬에서 작동할 path
    private static final String p = "/uploads/board2/summernote/";
    private static final ClassPathResource cpr = new ClassPathResource("static" +
            p);
    private static final String localRoot = "C:/Users/nam52/Downloads/YshProject_v2/bin/main/static";

    public static String upload_summernote(MultipartFile a) {
        // 업로드 하고
        JsonObject jo = new JsonObject();
        ClassPathResource cpr = new ClassPathResource("static" + p); // TODO local
        String newFilename = Long.toString(1111) + "_summernote_" + a.getOriginalFilename();

        try {
            File fileRoot = cpr.getFile(); // TODO local
            File tDirectory = new File(fileRoot, newFilename); // TODO local
            a.transferTo(tDirectory); // TODO local
            // 파일 옮기고
            // a.transferTo(new File(localRoot + p, newFilename)); // TODO ec2
            jo.addProperty("url", p + newFilename);
            // 옮긴경로+파일명 값 을 url이라는 이름으로 제이슨오브젝트에 넣고
            jo.addProperty("responseCode", "success");
            System.out.println("success");
            // 이게 성공했다고 responseCode에 success 값도 넣어준다
        } catch (IOException e) {
            // 실패하면(?) responseCode에 failed 넣어줌
            jo.addProperty("responseCode", "failed");
        }

        // 이제 성공이건 실패건 responseCode가 들어있는 제이슨오브젝트를 스트링형태로 바꿔서 리턴
        return jo.toString(); // 그 경로 돌려주기
    }
}