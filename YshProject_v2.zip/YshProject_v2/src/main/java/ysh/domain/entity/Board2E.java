package ysh.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Builder
@Table(name = "ncs_board2")
public class Board2E extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long no;
    @Column(nullable = false)
    private String subject;

    @Column(columnDefinition = "text not null")
    private String content;

    private int readCount;

    @JoinColumn(name = "email")
    @ManyToOne
    private MemberEntity member;

    public Board2E update(String subject, String content) {
        this.subject = subject;
        this.content = content;
        return this;
    }

}
