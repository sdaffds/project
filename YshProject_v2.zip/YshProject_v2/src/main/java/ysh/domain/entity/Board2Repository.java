package ysh.domain.entity;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Board2Repository extends JpaRepository<Board2Entity, Long> {

}
