package ysh.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Table(name = "ncs_board3")
@Entity//DB 와 매핑되는 클래스
public class NoticeEntity extends BaseEntity{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long no;
	@Column(nullable = false)
	private String subject;
	
	@Column(columnDefinition = "text not null")
	private String content;
	
	private int readCount;
	
	@JoinColumn(name = "email")
	@ManyToOne
	private MemberEntity member;
	
	public NoticeEntity update(String subject, String content) {
		this.subject=subject;
		this.content=content;
		return this;
	}
}
