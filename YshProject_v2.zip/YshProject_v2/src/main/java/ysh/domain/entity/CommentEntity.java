package ysh.domain.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
@Table(name="comment_entity")
public class CommentEntity extends BaseEntity{
	@Id
	@GeneratedValue
	private long id;
	private String comment_writer; //댓글작성자
	private String comment_content; //댓글내용
	@ManyToOne
	private BoardEntity board;
}
