package ysh.domain.entity;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CommentR extends JpaRepository<Comment, Long>{

	List<Comment> findByBoardNo(long a);
	
}
