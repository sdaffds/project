package ysh.service;

import java.security.Principal;

import org.springframework.ui.Model;

import ysh.domain.dto.notice.NoticeInsertDto;

public interface NoticeService {

	void save(NoticeInsertDto dto, Principal principal);

	void detail(long bno, Model model);

	void getList(Model model);

	void edit(long bno, String content);

	void deleteNotice(long bno);
	
}
