package ysh.service;

import java.security.Principal;

import org.springframework.ui.Model;

import ysh.domain.dto.board.BoardInsertDto;
import ysh.domain.entity.CommentEntity;

public interface BoardService {

	void save(BoardInsertDto dto, Principal principal);

	void getList(Model model);

	void detail(long bno, Model model);

	void getList2(Model model);

	void save2(BoardInsertDto dto, Principal principal);

	void detail2(long bno, Model model);

	void addCommentS(long detailNo, CommentEntity a, String name);

	void editCommentS(long comment_id, String comment_content);

	void delCommentS(long comment_id);
	
	void edit(long bno, String content);

	void edit2(long bno, String content);
	
	void deleteRow(long bno);
	
	void deleteRow2(long bno);
	
}
