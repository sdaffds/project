package ysh.service;

import java.security.Principal;

import org.springframework.ui.Model;

import ysh.domain.dto.board.BoardInsertDto;

public interface BoardService {

	void save(BoardInsertDto dto, Principal principal);


	void getList(Model model);


	void detail(long bno, Model model);

}
