package ysh.service;

import ysh.domain.dto.member.MemberSaveDto;

public interface MemberService {

	void save(MemberSaveDto dto);

}
