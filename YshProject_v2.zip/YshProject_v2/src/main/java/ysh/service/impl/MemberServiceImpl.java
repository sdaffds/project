package ysh.service.impl;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;
import ysh.domain.dto.member.MemberSaveDto;
import ysh.domain.entity.MemberEntity;
import ysh.domain.entity.MemberEntityRepository;
import ysh.security.MemberRole;
import ysh.service.MemberService;

@RequiredArgsConstructor
@Service
public class MemberServiceImpl implements MemberService {

	final MemberEntityRepository memberEntityRepository;
	
	final PasswordEncoder passwordEncoder;

	@Override
	public void save(MemberSaveDto dto) {
		MemberEntity entity=MemberEntity.builder()
					.email(dto.getEmail())
					//비밀번호는 인코딩
					.password(passwordEncoder.encode(dto.getPassword()))
					.name(dto.getName())
					.build();
		//role 적용 
		entity.addRole(MemberRole.USER);
		
		memberEntityRepository.save(entity);
		
	}

}
