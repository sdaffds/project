package ysh.service.impl;

import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;
import ysh.domain.dto.member.MemberSaveDto;
import ysh.domain.entity.MemberEntity;
import ysh.domain.entity.MemberEntityRepository;
import ysh.service.MemberService;

@RequiredArgsConstructor
@Service
public class MemberServiceImpl implements MemberService {

	final MemberEntityRepository memberEntityRepository;
	
	@Override
	public void save(MemberSaveDto dto) {
		MemberEntity entity=MemberEntity.builder().build();
		
		//비밀번호는 인코딩
		
		//role 적용 
		
		
		memberEntityRepository.save(entity);
		
	}

}
