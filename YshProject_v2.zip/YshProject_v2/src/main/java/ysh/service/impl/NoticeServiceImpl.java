package ysh.service.impl;

import java.security.Principal;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import ysh.domain.dto.notice.NoticeDetailDto;
import ysh.domain.dto.notice.NoticeInsertDto;
import ysh.domain.dto.notice.NoticeListDto;
import ysh.domain.entity.MemberEntity;
import ysh.domain.entity.NoticeEntity;
import ysh.domain.entity.NoticeEntityRepository;
import ysh.service.NoticeService;



@Service
public class NoticeServiceImpl implements NoticeService {

	@Autowired
	private NoticeEntityRepository repository;

	@Override
	public void save(NoticeInsertDto dto, Principal principal) {
		NoticeEntity entity = NoticeEntity.builder()
				.subject(dto.getSubject())
				.content(dto.getContent())
				.member(MemberEntity.builder().email(principal.getName()).build())
				.build();

		repository.save(entity);

	}

	@Override
	public void getList(Model model) {
		int page = 1;//0번페이지부터
		int size = 8;//한 페이지에서 8개의 list만 표시
		Pageable pageable = PageRequest.of(page - 1, size, Direction.DESC, "no");
		// NoticeEntity -> NoticeListDto 매핑해서 리턴
		
		Page<NoticeListDto> result = repository.findAll(pageable).map(NoticeListDto::new);
		model.addAttribute("list", result.getContent());
	}

	@Override
	public void detail(long bno, Model model) {
		model.addAttribute("detail",
				repository.findById(bno).map(NoticeDetailDto::new).orElse(null));
		//model.addAttribute("commentList",cr.findByBoardNo(bno));

	}
	
}
