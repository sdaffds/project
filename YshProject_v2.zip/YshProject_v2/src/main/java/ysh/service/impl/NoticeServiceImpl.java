package ysh.service.impl;

import java.security.Principal;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import ysh.domain.dto.notice.NoticeDetailDto;
import ysh.domain.dto.notice.NoticeInsertDto;
import ysh.domain.dto.notice.NoticeListDto;
import ysh.domain.entity.MemberEntity;
import ysh.domain.entity.NoticeEntity;
import ysh.domain.entity.NoticeEntityRepository;
import ysh.service.NoticeService;



@Service
public class NoticeServiceImpl implements NoticeService {

	@Autowired
	private NoticeEntityRepository repository;

	@Override
	public void save(NoticeInsertDto dto, Principal principal) {
		NoticeEntity entity = NoticeEntity.builder()
				.subject(dto.getSubject())
				.content(dto.getContent())
				.member(MemberEntity.builder().email(principal.getName()).build())
				.build();

		repository.save(entity);

	}

	@Override
	public void getList(Model model) {
		int page = 1;//0번페이지부터
		int size = 8;//한 페이지에서 8개의 list만 표시
		Pageable pageable = PageRequest.of(page - 1, size, Direction.DESC, "no");
		// NoticeEntity -> NoticeListDto 매핑해서 리턴
		
		Page<NoticeListDto> result = repository.findAll(pageable).map(NoticeListDto::new);
		model.addAttribute("list", result.getContent());
		
//		Page<NoticeListDto> result = repository.findAll() // List<Entity>
//												.stream()
//												.map(NoticeListDto :: new)	// Page<NoticeListDto>
//												.getContent()	// List<NoticeListDto>
		
	}

	@Override
	public void detail(long bno, Model model) {
//		repository에서 bno라는 id를 가진 게시글을 찾아서 가져와 Entity라는 java의 object에 넣은
//		DB에서, bno라는 id를 가진애를 찾아서 repository를 통해 그 값을 NoticeEntity 타입으로 가져온다
		NoticeEntity a =repository.findById(bno).get();
//		그놈의 readcount를 1 올려서
		a.increase_readCount();
//		저장
		repository.save(a);
//		a : 기존 b : a랑 다 똑같은데 readCount만 1 올린애
//		저장된 후 bno라는 id를 가진 게시글을 다시 찾아서온 다음, 아랫줄 실행
		model.addAttribute("detail",
				repository
					.findById(bno)		// bno를 id로 가지는애 가져오기 Entity
					.map(NoticeDetailDto::new)	// NoticeDetailDto::함수명
					.orElse(null));	// 원하는 결과 : DetailDto
		//model.addAttribute("commentList",cr.findByBoardNo(bno));
	}

	@Override
	public void edit(long bno, String content) {
		NoticeEntity a = repository.findById(bno).get();
		a.setContent(content);
		repository.save(a);
//		public String content -> a.content = content2;
//		@Setter
//		private String content -> a.setContent(content2);
	}
	
}
