package ysh.service.impl;

import java.security.Principal;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import ysh.domain.dto.board.BoardDetailDto;
import ysh.domain.dto.board.BoardInsertDto;
import ysh.domain.dto.board.BoardListDto;
import ysh.domain.dto.board2.Board2ListDto;
import ysh.domain.entity.Board2Entity;
import ysh.domain.entity.Board2Repository;
import ysh.domain.entity.BoardEntity;
import ysh.domain.entity.BoardEntityRepository;
import ysh.domain.entity.CommentEntity;
import ysh.domain.entity.CommentRepository;
import ysh.domain.entity.MemberEntity;
import ysh.service.BoardService;

@Service
public class BoardServiceImpl implements BoardService {

	@Autowired
	private BoardEntityRepository repository;
	@Autowired
	private Board2Repository b2r;
	@Autowired
	private CommentRepository cr;

	@Override
	public void save(BoardInsertDto dto, Principal principal) {
		BoardEntity entity = BoardEntity.builder()
				.subject(dto.getSubject())
				.content(dto.getContent())
				.member(MemberEntity.builder().email(principal.getName()).build())
				.build();

		repository.save(entity);

	}

	//list페이지 보여지는 게시글
	@Override
	public void getList(Model model) {
		int page = 1;
		int size = 8;
//		page[3] = {a, b, c} // List<char> d = {'e', 'f', 'g'}
//		d[0] = 'e', d[1] = 'f', d[2] = 'g'
//		page[page-1]=a, page[1]=b, page[2]=c, page.size()=3
//		page[page.size()-1] sss/sss/1
		Pageable pageable = PageRequest.of(page - 1, size, Direction.DESC, "no");
//		descend : 감소, ascend : 증가
		// BoardEntity -> BoardListDto 매핑해서 리턴
		Page<BoardListDto> result = repository.findAll(pageable).map(BoardListDto::new);
		model.addAttribute("list", result.getContent());
	}

	//게시글 detail page에서 보여질 정보 가져가기 (게시글 본문, 제목 등등.. + 그 게시글의 댓글들)
	@Override
	public void detail(long bno, Model model) {
//		Entity a = Entity.builder...
//		Dto b = new Dto(a);
//		3번 게시글의 전체 내용을 들고와
		BoardEntity a = repository.findById(bno).get();
		BoardDetailDto b = new BoardDetailDto(a);
		model.addAttribute("detail", b);
//		${detail.title}
		
		List<CommentEntity> c = cr.findByBoardNo(bno);
		model.addAttribute("commentList",c);
	}

	@Override
	public void getList2(Model model) {
		int page = 1;
		int size = 8;
		Pageable pageable = PageRequest.of(page - 1, size, Direction.DESC, "no");
		// BoardEntity -> BoardListDto 매핑해서 리턴
		Page<Board2ListDto> result = b2r.findAll(pageable).map(Board2ListDto::new);
		model.addAttribute("list", result.getContent());
	}

	@Override
	public void save2(BoardInsertDto dto, Principal principal) {
		Board2Entity entity = Board2Entity.builder()
				.subject(dto.getSubject())
				.content(dto.getContent())
				.member(MemberEntity.builder().email(principal.getName()).build())
				.build();

		b2r.save(entity);
	}

	@Override
	public void detail2(long bno, Model model) {
		//service에서 bno라는 id값을 찾아와서
		Board2Entity a = b2r.findById(bno).get();
		//readCount만 1 증가 변경
		a.setReadCount(a.getReadCount()+1);
		//수정된 값을 가진 Entity를 repository를 이용해 db에 저장
		b2r.save(a);
		//bno를 id로 가지는 게시글 db에서 찾아오기 (repository 사용)
		Board2Entity c = b2r.findById(bno).get();
		//찾아온 게시글 dto로 변환
		BoardDetailDto d = new BoardDetailDto(c); /*엔터티였던놈을 dto로 바꿔야지*/
		//dto를 model
		model.addAttribute("detail", d);
	}
		
	public void deleteRow(long bno) {
		b2r.deleteById(bno);
	}

	@Override
	public void addCommentS(long detailNo, CommentEntity a, String name) {
		CommentEntity data = CommentEntity.builder()
							.comment_writer(name)
							.comment_content(a.getComment_content())
							.board(BoardEntity.builder().no(detailNo).build())
							.build();
		cr.save(data);
	}

	@Override
	public void editCommentS(long comment_id, String comment_content) {
//		comment_id : 수정하려는 comment 자체의 id
//		comment_content : 수정하려는 comment의 새로운 내용
//		id값으로 기존 comment Entity를 불러와서 그놈의 comment만 교체해서 update
		Optional<CommentEntity> a = cr.findById(comment_id);
		if(a.isPresent()) {
			CommentEntity b = a.get();
			b.setComment_content(comment_content);
			cr.save(b);
		}
	}

	@Override
	public void delCommentS(long comment_id) {
		cr.deleteById(comment_id);
	}

	@Override
	public void edit2(long bno, String content) {
//		bno를 id로 가지는 기존게시글 가져오기
		Board2Entity b = b2r.findById(bno).get();
//				a.b : a에 있는 b를 뭘 하겠다 repository 안에있는 findById(bno)
//		게시글의 내용을 새로운 content로 수정
		b.setContent(content);
		b2r.save(b);
	}

}