package ysh.service.impl;

import java.security.Principal;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import ysh.domain.dto.board.BoardDetailDto;
import ysh.domain.dto.board.BoardInsertDto;
import ysh.domain.dto.board.BoardListDto;
import ysh.domain.dto.board2.Board2ListDto;
import ysh.domain.entity.Board2Entity;
import ysh.domain.entity.Board2Repository;
import ysh.domain.entity.BoardEntity;
import ysh.domain.entity.BoardEntityRepository;
import ysh.domain.entity.CommentEntity;
import ysh.domain.entity.CommentRepository;
import ysh.domain.entity.MemberEntity;
import ysh.service.BoardService;

@Service
public class BoardServiceImpl implements BoardService {

	@Autowired
	private BoardEntityRepository repository;
	@Autowired
	private Board2Repository b2r;
	@Autowired
	private CommentRepository cr;

	@Override
	public void save(BoardInsertDto dto, Principal principal) {
		BoardEntity entity = BoardEntity.builder()
				.subject(dto.getSubject())
				.content(dto.getContent())
				.member(MemberEntity.builder().email(principal.getName()).build())
				.build();

		repository.save(entity);

	}

	@Override
	public void getList(Model model) {
		int page = 1;
		int size = 8;
		Pageable pageable = PageRequest.of(page - 1, size, Direction.DESC, "no");
		// BoardEntity -> BoardListDto 매핑해서 리턴
		Page<BoardListDto> result = repository.findAll(pageable).map(BoardListDto::new);
		model.addAttribute("list", result.getContent());
	}

	@Override
	public void detail(long bno, Model model) {
		model.addAttribute("detail",
				repository.findById(bno).map(BoardDetailDto::new).orElse(null));
		model.addAttribute("commentList",cr.findByBoardNo(bno));

	}

	@Override
	public void getList2(Model model) {
		int page = 1;
		int size = 8;
		Pageable pageable = PageRequest.of(page - 1, size, Direction.DESC, "no");
		// BoardEntity -> BoardListDto 매핑해서 리턴
		Page<Board2ListDto> result = b2r.findAll(pageable).map(Board2ListDto::new);
		model.addAttribute("list", result.getContent());
	}

	@Override
	public void save2(BoardInsertDto dto, Principal principal) {
		Board2Entity entity = Board2Entity.builder()
				.subject(dto.getSubject())
				.content(dto.getContent())
				.member(MemberEntity.builder().email(principal.getName()).build())
				.build();

		b2r.save(entity);
	}

	@Override
	public void detail2(long bno, Model model) {
		model.addAttribute("detail",
				b2r.findById(bno).map(BoardDetailDto::new).orElse(null));
	}

	@Override
	public void addCommentS(long detailNo, CommentEntity a, String name) {
		CommentEntity data = CommentEntity.builder()
							.comment_writer(name)
							.comment_content(a.getComment_content())
							.board(BoardEntity.builder().no(detailNo).build())
							.build();
		cr.save(data);
	}

	@Override
	public void editCommentS(long comment_id, String comment_content) {
//		comment_id : 수정하려는 comment 자체의 id
//		comment_content : 수정하려는 comment의 새로운 내용
//		id값으로 기존 comment Entity를 불러와서 그놈의 comment만 교체해서 update
		Optional<CommentEntity> a = cr.findById(comment_id);
		if(a.isPresent()) {
			CommentEntity b = a.get();
			b.setComment_content(comment_content);
			cr.save(b);
		}
	}

	@Override
	public void delCommentS(long comment_id) {
		cr.deleteById(comment_id);
	}

	@Override
	public void edit2(long bno, String content) {
//		bno를 id로 가지는 기존게시글 가져오기
		Board2Entity b = b2r.findById(bno).get();
//				a.b : a에 있는 b를 뭘 하겠다 repository 안에있는 findById(bno)
//		게시글의 내용을 새로운 content로 수정
		b.setContent(content);
		b2r.save(b);
	}

}