package ysh.service.impl;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import ysh.domain.dto.board3.BoardDetailDto;
import ysh.domain.dto.board3.BoardInsertDto;
import ysh.domain.dto.board3.BoardListDto;
import ysh.domain.entity.BoardEntity;
import ysh.domain.entity.BoardEntityRepository;
import ysh.domain.entity.MemberEntity;
import ysh.service.BoardService;

@Service
public class BoardServiceImpl implements BoardService{
	
	@Autowired
	private BoardEntityRepository repository;
	
	@Override
	public void save(BoardInsertDto dto, Principal principal) {
		BoardEntity entity=BoardEntity.builder()
				.subject(dto.getSubject())
				.content(dto.getEditordata())
				.member(MemberEntity.builder().email(principal.getName()).build())
				.build();
		
		repository.save(entity);
		
	}

	@Override
	public void getList(Model model) {
		int page=1;
		int size=8;
		Pageable pageable=PageRequest.of(page-1, size, Direction.DESC, "no");
		//BoardEntity -> BoardListDto 매핑해서 리턴
		Page<BoardListDto> result=repository.findAll(pageable).map(BoardListDto::new);
		model.addAttribute("list", result.getContent());
		
	}

	@Override
	public void detail(long bno, Model model) {
		model.addAttribute("detail", 
		repository.findById(bno).map(BoardDetailDto::new).orElse(null) );
		
	}

	

}
