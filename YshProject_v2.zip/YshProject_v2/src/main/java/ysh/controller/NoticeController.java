package ysh.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

import ysh.domain.dto.notice.NoticeInsertDto;
import ysh.service.NoticeService;

@Controller
public class NoticeController {

	@Autowired
	NoticeService service;

	// 게시글 목록
	@GetMapping("/notices")
	public String list(Model model) {// 공지사항페이지로 이동할때 DB의 데이터 갖고가야하기에 Model 객체를통해서 전달
		service.getList(model);
		return "notice/list";
	}

	// 게시글 작성화면
	@GetMapping("/notices/write")
	public String writePage() {
		return "notice/write";
	}

	// 게시글 작성처리
	@PostMapping("/notices/write")
	public String write(NoticeInsertDto dto, Principal principal) {
		service.save(dto, principal);
		return "redirect:/notices";
	}

	// 게시글 상세화면
	@GetMapping("/notices/{bno}")
	public String detail(@PathVariable long bno, Model model) {
//		bno를 받아와서*
//		그 bno를 가진 게시글을 불러와서
		service.detail(bno, model);
//		페이지를 이동해서 거기서 보여줄거
		return "notice/detail";	// html ${ddddd}
	}

	// 게시글 수정
	@PutMapping("/notices/{bno}")
	public String update(@PathVariable long bno, String content) {
		service.edit(bno, content);
		return "redirect:/notices/" + bno;
	}
	

	// 게시글 삭제
	@DeleteMapping("/notices/{bno}")
	public String delete(@PathVariable long bno) {
		return "redirect:/notices";
	}

}
