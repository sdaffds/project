package ysh.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import lombok.RequiredArgsConstructor;
import ysh.domain.dto.member.MemberSaveDto;
import ysh.service.MemberService;
import ysh.service.impl.MemberServiceImpl;

@RequiredArgsConstructor
@Controller
public class LogController {
	
	
	final MemberService service;
	

	@GetMapping("/sign/signin")
	public String loginPage() {
		return "member/login";
	}
	//회원가입 페이지이동 처리
	@GetMapping("/sign/signup")
	public String logup() {
		return "member/registration";
	}
	
	//회원 등록 처리
	@PostMapping("/sign/signup")
	public String logup(MemberSaveDto dto) {
		
		service.save(dto);
		
		return "member/login";
	}
	
	
}
