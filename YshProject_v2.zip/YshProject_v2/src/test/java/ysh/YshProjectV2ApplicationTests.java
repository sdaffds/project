package ysh;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;

import ysh.domain.entity.MemberEntity;
import ysh.domain.entity.MemberEntityRepository;
import ysh.security.MemberRole;

@SpringBootTest
class YshProjectV2ApplicationTests {
	
	@Autowired
	MemberEntityRepository memberEntityRepository;
	
	@Autowired
	PasswordEncoder passwordEncoder;//비밀번호 암호화
	
	//@Test
	void 회원저장테스트() {
		MemberEntity entity=MemberEntity.builder()
				.email("test01@test.com").password(passwordEncoder.encode("1234")).name("test01")
				.build();
		
		entity.addRole(MemberRole.USER);
		
		memberEntityRepository.save(entity);
	}

}
